import qrcode

url = "https://melonmice.github.io/birthday-website/"

qr = qrcode.make(url)

qr.save("birthday_qr.png")

print("QR Code generated successfully! Scan 'birthday_qr.png' to see the birthday wish.")
